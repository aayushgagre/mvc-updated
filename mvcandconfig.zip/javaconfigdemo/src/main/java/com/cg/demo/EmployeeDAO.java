package com.cg.demo;

import org.springframework.stereotype.Repository;

@Repository("dao")
public class EmployeeDAO {

}
