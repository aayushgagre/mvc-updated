package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;

@Configuration //This is the replacement of spring.xml
@ComponentScan("com.cg.demo") //pick all classes from com.cg.demo
public class AppConfig {

	
}
